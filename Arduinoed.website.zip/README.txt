The Arduinoed Website is included in the build folder and can be viewed by opening ./build/index.html in a web browser.

By:
Mitch Myburgh
Tumelo Makgaka
